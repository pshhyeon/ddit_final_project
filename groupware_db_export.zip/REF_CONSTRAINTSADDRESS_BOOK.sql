--------------------------------------------------------
--  Ref Constraints for Table ADDRESS_BOOK
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."ADDRESS_BOOK" ADD CONSTRAINT "FK_EMPLOYEE_TO_ADDRESS_BOOK_1" FOREIGN KEY ("EMPL_ID")
	  REFERENCES "TEAM1_202312_2F"."EMPLOYEE" ("EMPL_ID") ENABLE;

--------------------------------------------------------
--  Ref Constraints for Table EMPLOYEE
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."EMPLOYEE" ADD CONSTRAINT "FK_DEPARTMENT_TO_EMPLOYEE_1" FOREIGN KEY ("DEPT_CD")
	  REFERENCES "TEAM1_202312_2F"."DEPARTMENT" ("DEPT_CD") ENABLE;

--------------------------------------------------------
--  DDL for Sequence SEQ_APRV_ID
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_APRV_ID"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 361 CACHE 20 NOORDER  CYCLE ;

--------------------------------------------------------
--  DDL for Sequence SEQ_FORM_BP_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_FORM_BP_NO"  MINVALUE 1 MAXVALUE 99999999 INCREMENT BY 1 START WITH 101 CACHE 20 NOORDER  NOCYCLE ;

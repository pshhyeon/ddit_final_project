--------------------------------------------------------
--  Ref Constraints for Table APPROVAL_LINE
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."APPROVAL_LINE" ADD CONSTRAINT "FK_EMPLOYEE_TO_APPROVAL_LINE_1" FOREIGN KEY ("EMPL_ID")
	  REFERENCES "TEAM1_202312_2F"."EMPLOYEE" ("EMPL_ID") ENABLE;

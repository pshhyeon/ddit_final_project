--------------------------------------------------------
--  DDL for Sequence SEQ_CN_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_CN_NO"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 121 NOCACHE  ORDER  NOCYCLE ;

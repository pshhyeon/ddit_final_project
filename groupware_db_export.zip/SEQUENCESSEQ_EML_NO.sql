--------------------------------------------------------
--  DDL for Sequence SEQ_EML_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_EML_NO"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 982 NOCACHE  ORDER  CYCLE ;

REM INSERTING into TEAM1_202312_2F.FIXURES
SET DEFINE OFF;
Insert into TEAM1_202312_2F.FIXURES (FIX_NO,FIX_NM,FIX_TY_CD,FIX_IMG) values (1,'��Ʈ��','FXR0101','/upload/FXR0101.jpg');
Insert into TEAM1_202312_2F.FIXURES (FIX_NO,FIX_NM,FIX_TY_CD,FIX_IMG) values (2,'�����','FXR0102','/upload/FXR0102.jpg');
Insert into TEAM1_202312_2F.FIXURES (FIX_NO,FIX_NM,FIX_TY_CD,FIX_IMG) values (3,'��������Ʈ','FXR0103','/upload/FXR0103.jpg');
Insert into TEAM1_202312_2F.FIXURES (FIX_NO,FIX_NM,FIX_TY_CD,FIX_IMG) values (4,'�����ϵ�','FXR0104','/upload/FXR0104.jpg');
Insert into TEAM1_202312_2F.FIXURES (FIX_NO,FIX_NM,FIX_TY_CD,FIX_IMG) values (5,'����Ŀ','FXR0105','/upload/FXR0105.jpg');

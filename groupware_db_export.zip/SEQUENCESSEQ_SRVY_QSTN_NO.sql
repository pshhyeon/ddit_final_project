--------------------------------------------------------
--  DDL for Sequence SEQ_SRVY_QSTN_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_SRVY_QSTN_NO"  MINVALUE 1 MAXVALUE 10000 INCREMENT BY 1 START WITH 41 CACHE 40 NOORDER  NOCYCLE ;

--------------------------------------------------------
--  Ref Constraints for Table APPROVAL_LINE_TEMPLATE
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."APPROVAL_LINE_TEMPLATE" ADD CONSTRAINT "APPROVAL_LINE_TEMPLATE_FK1" FOREIGN KEY ("EMPL_ID")
	  REFERENCES "TEAM1_202312_2F"."EMPLOYEE" ("EMPL_ID") ENABLE;

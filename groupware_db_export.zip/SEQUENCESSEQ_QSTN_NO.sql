--------------------------------------------------------
--  DDL for Sequence SEQ_QSTN_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_QSTN_NO"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 531 CACHE 20 NOORDER  CYCLE ;

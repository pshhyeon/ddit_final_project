--------------------------------------------------------
--  Ref Constraints for Table SURVEY_QITEM
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."SURVEY_QITEM" ADD CONSTRAINT "SURVEY_ANSWER_FK1" FOREIGN KEY ("QSTN_NO")
	  REFERENCES "TEAM1_202312_2F"."SURVEY_QSTN" ("QSTN_NO") ENABLE;

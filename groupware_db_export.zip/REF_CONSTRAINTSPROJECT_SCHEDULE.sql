--------------------------------------------------------
--  Ref Constraints for Table PROJECT_SCHEDULE
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."PROJECT_SCHEDULE" ADD CONSTRAINT "PROJECT_SCHEDULE_FK1" FOREIGN KEY ("PROJ_NO")
	  REFERENCES "TEAM1_202312_2F"."PROJECTS" ("PROJ_NO") ENABLE;

--------------------------------------------------------
--  DDL for Sequence SEQ_FILE_GROUP_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_FILE_GROUP_NO"  MINVALUE 1 MAXVALUE 10000 INCREMENT BY 1 START WITH 226 NOCACHE  ORDER  CYCLE ;

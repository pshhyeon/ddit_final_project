--------------------------------------------------------
--  Ref Constraints for Table HD_APLY_FORM_DATA
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."HD_APLY_FORM_DATA" ADD CONSTRAINT "HD_APLY_FORM_DATA_FK2" FOREIGN KEY ("FORM_SE_NO")
	  REFERENCES "TEAM1_202312_2F"."FORM_HD_SE" ("FORM_SE_NO") ENABLE;

--------------------------------------------------------
--  DDL for Sequence SEQ_WORK_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_WORK_NO"  MINVALUE 1 MAXVALUE 9999 INCREMENT BY 1 START WITH 4257 NOCACHE  ORDER  CYCLE ;

--------------------------------------------------------
--  Ref Constraints for Table PROJECT_TASK
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."PROJECT_TASK" ADD CONSTRAINT "PROJECT_TASK_FK2" FOREIGN KEY ("PROJ_NO", "EMPL_ID")
	  REFERENCES "TEAM1_202312_2F"."PROJECT_PRTCP" ("PROJ_NO", "EMPL_ID") ENABLE;

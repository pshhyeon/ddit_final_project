--------------------------------------------------------
--  DDL for Sequence SEQ_MRE_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_MRE_NO"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 696 NOCACHE  ORDER  CYCLE ;

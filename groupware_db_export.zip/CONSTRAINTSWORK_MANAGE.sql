--------------------------------------------------------
--  Constraints for Table WORK_MANAGE
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."WORK_MANAGE" MODIFY ("WORK_NO" NOT NULL ENABLE);
  ALTER TABLE "TEAM1_202312_2F"."WORK_MANAGE" MODIFY ("WMAN_CD" NOT NULL ENABLE);
  ALTER TABLE "TEAM1_202312_2F"."WORK_MANAGE" MODIFY ("WMAN_DT" NOT NULL ENABLE);

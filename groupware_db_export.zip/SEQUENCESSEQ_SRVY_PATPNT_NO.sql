--------------------------------------------------------
--  DDL for Sequence SEQ_SRVY_PATPNT_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_SRVY_PATPNT_NO"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 1001 CACHE 20 NOORDER  CYCLE ;

--------------------------------------------------------
--  Ref Constraints for Table DEPT_MVNV_FORM_DATA
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."DEPT_MVNV_FORM_DATA" ADD CONSTRAINT "DEPT_MVNV_FORM_DATA_FK1" FOREIGN KEY ("FORM_CD")
	  REFERENCES "TEAM1_202312_2F"."APPROVAL_FORM" ("FORM_CD") ENABLE;

--------------------------------------------------------
--  Ref Constraints for Table METTING_ROOM_RSVT
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."METTING_ROOM_RSVT" ADD CONSTRAINT "METTING_ROOM_RSVT_FK1" FOREIGN KEY ("ROOM_NO")
	  REFERENCES "TEAM1_202312_2F"."METTING_ROOM" ("ROOM_NO") ENABLE;

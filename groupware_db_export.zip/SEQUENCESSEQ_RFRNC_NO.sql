--------------------------------------------------------
--  DDL for Sequence SEQ_RFRNC_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_RFRNC_NO"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 221 CACHE 20 NOORDER  NOCYCLE ;

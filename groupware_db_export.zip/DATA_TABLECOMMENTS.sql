REM INSERTING into TEAM1_202312_2F.COMMENTS
SET DEFINE OFF;
Insert into TEAM1_202312_2F.COMMENTS (CMNT_NO,EMPL_ID,BBS_NO,CMNT_WRT_DT,CMNT_MDFCN_DT,CMNT_CN) values (111,'20180122',176,to_date('2024/07/27','yyyy/MM/DD'),to_date('2024/07/27','yyyy/MM/DD'),'���� ���� �����Դϴ�!');
Insert into TEAM1_202312_2F.COMMENTS (CMNT_NO,EMPL_ID,BBS_NO,CMNT_WRT_DT,CMNT_MDFCN_DT,CMNT_CN) values (109,'20180122',2,to_date('2024/07/22','yyyy/MM/DD'),to_date('2024/07/22','yyyy/MM/DD'),'�Խñۿ� ������ ������ �ֽ��ϴ�!  ');
Insert into TEAM1_202312_2F.COMMENTS (CMNT_NO,EMPL_ID,BBS_NO,CMNT_WRT_DT,CMNT_MDFCN_DT,CMNT_CN) values (171,'20180912',176,to_date('2024/08/02','yyyy/MM/DD'),to_date('2024/08/02','yyyy/MM/DD'),'�����մϴ�!');
Insert into TEAM1_202312_2F.COMMENTS (CMNT_NO,EMPL_ID,BBS_NO,CMNT_WRT_DT,CMNT_MDFCN_DT,CMNT_CN) values (191,'20180912',176,to_date('2024/08/05','yyyy/MM/DD'),to_date('2024/08/05','yyyy/MM/DD'),'�����߽��ϴ�~');

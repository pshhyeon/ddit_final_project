--------------------------------------------------------
--  DDL for Sequence SEQ_SURV_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_SURV_NO"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 511 CACHE 20 NOORDER  CYCLE ;

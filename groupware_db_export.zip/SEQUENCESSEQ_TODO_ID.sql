--------------------------------------------------------
--  DDL for Sequence SEQ_TODO_ID
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_TODO_ID"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 121 NOCACHE  ORDER  CYCLE ;

--------------------------------------------------------
--  DDL for Sequence SEQ_APRV_LINE_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_APRV_LINE_NO"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 401 CACHE 20 NOORDER  CYCLE ;

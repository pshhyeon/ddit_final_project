--------------------------------------------------------
--  Ref Constraints for Table TODOLIST
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."TODOLIST" ADD CONSTRAINT "FK_EMPLOYEE_TO_TODOLIST_1" FOREIGN KEY ("EMPL_ID")
	  REFERENCES "TEAM1_202312_2F"."EMPLOYEE" ("EMPL_ID") ENABLE;

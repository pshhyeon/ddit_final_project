--------------------------------------------------------
--  Constraints for Table EMP_AUTH
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."EMP_AUTH" MODIFY ("EMPL_ID" NOT NULL ENABLE);
  ALTER TABLE "TEAM1_202312_2F"."EMP_AUTH" MODIFY ("AUTH" NOT NULL ENABLE);

--------------------------------------------------------
--  Ref Constraints for Table CHAT_MESSAGE
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."CHAT_MESSAGE" ADD CONSTRAINT "CHAT_MESSAGE_FK2" FOREIGN KEY ("CHTT_ROOM_NO", "EMPL_ID")
	  REFERENCES "TEAM1_202312_2F"."CHAT_ROOM_JOIN" ("CHTT_ROOM_NO", "EMPL_ID") ENABLE;

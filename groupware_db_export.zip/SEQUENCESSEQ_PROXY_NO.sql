--------------------------------------------------------
--  DDL for Sequence SEQ_PROXY_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_PROXY_NO"  MINVALUE 1 MAXVALUE 99999999999 INCREMENT BY 1 START WITH 401 CACHE 20 NOORDER  CYCLE ;

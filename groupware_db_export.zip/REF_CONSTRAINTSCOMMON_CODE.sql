--------------------------------------------------------
--  Ref Constraints for Table COMMON_CODE
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."COMMON_CODE" ADD CONSTRAINT "COMMON_CODE_FK1" FOREIGN KEY ("CM_CD_GROUP_ID")
	  REFERENCES "TEAM1_202312_2F"."COMMON_CODE_GROUP" ("CM_CD_GROUP_ID") ENABLE;

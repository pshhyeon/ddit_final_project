--------------------------------------------------------
--  Ref Constraints for Table EMP_AUTH
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."EMP_AUTH" ADD CONSTRAINT "FK_EMPLOYEE_TO_EMP_AUTH_1" FOREIGN KEY ("EMPL_ID")
	  REFERENCES "TEAM1_202312_2F"."EMPLOYEE" ("EMPL_ID") ENABLE;

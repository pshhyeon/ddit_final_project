--------------------------------------------------------
--  Ref Constraints for Table SURVEY_QSTN
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."SURVEY_QSTN" ADD CONSTRAINT "FK_SURVEY_TO_SURVEY_QUESTION_1" FOREIGN KEY ("SURV_NO")
	  REFERENCES "TEAM1_202312_2F"."SURVEY" ("SURV_NO") ENABLE;

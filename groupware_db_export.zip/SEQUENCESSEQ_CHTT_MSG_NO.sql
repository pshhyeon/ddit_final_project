--------------------------------------------------------
--  DDL for Sequence SEQ_CHTT_MSG_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_CHTT_MSG_NO"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 111 CACHE 20 NOORDER  CYCLE ;

--------------------------------------------------------
--  DDL for Sequence SEQ_PROJ_SCHDL_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_PROJ_SCHDL_NO"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 831 CACHE 20 NOORDER  CYCLE ;

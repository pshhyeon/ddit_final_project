--------------------------------------------------------
--  Ref Constraints for Table ALARM
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."ALARM" ADD CONSTRAINT "FK_EMPLOYEE_TO_ALRAM_1" FOREIGN KEY ("EMPL_ID")
	  REFERENCES "TEAM1_202312_2F"."EMPLOYEE" ("EMPL_ID") ENABLE;

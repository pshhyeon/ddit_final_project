--------------------------------------------------------
--  Ref Constraints for Table WORKS
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."WORKS" ADD CONSTRAINT "FK_EMPLOYEE_TO_WORKS_1" FOREIGN KEY ("EMPL_ID")
	  REFERENCES "TEAM1_202312_2F"."EMPLOYEE" ("EMPL_ID") ENABLE;

--------------------------------------------------------
--  Ref Constraints for Table BOARD
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."BOARD" ADD CONSTRAINT "FK_EMPLOYEE_TO_BOARD_1" FOREIGN KEY ("EMPL_ID")
	  REFERENCES "TEAM1_202312_2F"."EMPLOYEE" ("EMPL_ID") ENABLE;

--------------------------------------------------------
--  Ref Constraints for Table MENU
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."MENU" ADD CONSTRAINT "FK_MENU_TO_MENU_1" FOREIGN KEY ("UP_MENU_ID")
	  REFERENCES "TEAM1_202312_2F"."MENU" ("MENU_ID") ENABLE;

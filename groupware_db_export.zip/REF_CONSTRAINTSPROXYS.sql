--------------------------------------------------------
--  Ref Constraints for Table PROXYS
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."PROXYS" ADD CONSTRAINT "FK_EMPLOYEE_TO_PROXYS_1" FOREIGN KEY ("EMPL_ID")
	  REFERENCES "TEAM1_202312_2F"."EMPLOYEE" ("EMPL_ID") ENABLE;

--------------------------------------------------------
--  DDL for Sequence SEQ_SURV_ANS_CN_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_SURV_ANS_CN_NO"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 471 CACHE 20 NOORDER  CYCLE ;

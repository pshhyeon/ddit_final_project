--------------------------------------------------------
--  Ref Constraints for Table TODOLIST_CONTENT
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."TODOLIST_CONTENT" ADD CONSTRAINT "TODOLIST_CONTENT_FK1" FOREIGN KEY ("TODO_ID")
	  REFERENCES "TEAM1_202312_2F"."TODOLIST" ("TODO_ID") ENABLE;

--------------------------------------------------------
--  Ref Constraints for Table WORK_MANAGE
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."WORK_MANAGE" ADD CONSTRAINT "FK_WORKS_TO_WORK_MANAGE_1" FOREIGN KEY ("WORK_NO")
	  REFERENCES "TEAM1_202312_2F"."WORKS" ("WORK_NO") ENABLE;

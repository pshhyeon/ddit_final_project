--------------------------------------------------------
--  DDL for Sequence SEQ_ALRAM_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_ALRAM_NO"  MINVALUE 1 MAXVALUE 10000 INCREMENT BY 1 START WITH 311 CACHE 20 NOORDER  CYCLE ;

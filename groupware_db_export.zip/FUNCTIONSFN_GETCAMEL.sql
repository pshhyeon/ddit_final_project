--------------------------------------------------------
--  DDL for Function FN_GETCAMEL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "TEAM1_202312_2F"."FN_GETCAMEL" (COLUMN_NAME IN VARCHAR2)
RETURN VARCHAR2
IS
RSLT VARCHAR2(30);
BEGIN
--ī��ǥ��� ��ȯ(SITE_NUM -> siteNum)
SELECT LOWER(SUBSTR(REPLACE(INITCAP(COLUMN_NAME),'_'),1,1))
|| SUBSTR(REPLACE(INITCAP(COLUMN_NAME),'_'),2) INTO RSLT
FROM DUAL;
--����
RETURN RSLT;
END;

/

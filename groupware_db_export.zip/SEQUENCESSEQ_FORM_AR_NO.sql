--------------------------------------------------------
--  DDL for Sequence SEQ_FORM_AR_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_FORM_AR_NO"  MINVALUE 1 MAXVALUE 99999999 INCREMENT BY 1 START WITH 81 CACHE 20 NOORDER  NOCYCLE ;

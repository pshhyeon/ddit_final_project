--------------------------------------------------------
--  Ref Constraints for Table APPROVAL_DOCUMENT
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."APPROVAL_DOCUMENT" ADD CONSTRAINT "APPROVAL_DOCUMENT_FK1" FOREIGN KEY ("EMPL_ID")
	  REFERENCES "TEAM1_202312_2F"."EMPLOYEE" ("EMPL_ID") ENABLE;

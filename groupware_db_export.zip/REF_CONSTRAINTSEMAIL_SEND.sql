--------------------------------------------------------
--  Ref Constraints for Table EMAIL_SEND
--------------------------------------------------------

  ALTER TABLE "TEAM1_202312_2F"."EMAIL_SEND" ADD CONSTRAINT "FK_EMPLOYEE_TO_EMAIL_SEND_1" FOREIGN KEY ("EMPL_ID")
	  REFERENCES "TEAM1_202312_2F"."EMPLOYEE" ("EMPL_ID") ENABLE;

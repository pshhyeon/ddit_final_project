--------------------------------------------------------
--  DDL for Sequence SEQ_APRV_TEMP_CD
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_APRV_TEMP_CD"  MINVALUE 1 MAXVALUE 9999999999999999 INCREMENT BY 1 START WITH 124 CACHE 20 NOORDER  NOCYCLE ;

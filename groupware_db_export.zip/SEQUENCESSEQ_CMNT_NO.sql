--------------------------------------------------------
--  DDL for Sequence SEQ_CMNT_NO
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM1_202312_2F"."SEQ_CMNT_NO"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 211 CACHE 20 NOORDER  CYCLE ;
